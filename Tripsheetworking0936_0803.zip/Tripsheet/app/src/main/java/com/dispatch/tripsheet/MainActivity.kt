package com.dispatch.tripsheet

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val list : MutableList<String> = ArrayList()
        list.add("Deon")
        list.add("Leon")
        list.add("David")
        list.add("Dick")
        list.add("Jim")
        list.add("Harry")


        val adapter = ArrayAdapter( this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, list)
        val spinner: Spinner = findViewById(R.id.spnTest)

        spinner.adapter = adapter

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                val item :String = list[p2]

                Toast.makeText(this@MainActivity, "Driver $item selected", Toast.LENGTH_SHORT).show()
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
                //empty
            }


        }

        limitDropDownHeight(spinner)


    }
    fun limitDropDownHeight(spinner: Spinner){



        val popup = Spinner::class.java.getDeclaredField( "mPopup")
        popup.isAccessible = true

        val popupWindow = popup.get(spinner)as ListPopupWindow

        popupWindow.height = (200 * resources.displayMetrics.density).toInt()



    }
}