package com.dispatch.tripsheet

class Weight {


}